exports = function(idTarea, nuevoEstado){
  /*
    Accessing application's values:
    var x = context.values.get("value_name");

    Accessing a mongodb service:
    var collection = context.services.get("mongodb-atlas").db("dbname").collection("coll_name");
    var doc = collection.findOne({owner_id: context.user.id});

    To call other named functions:
    var result = context.functions.execute("function_name", arg1, arg2);

    Try running in the console below.
  */
  
  return new Promise( async (resolve, reject) => {

    let esquema = context
      .services
      .get("mongodb-atlas")
      .db("esquema_tareas")
    let coleccionTareas = esquema.collection("tareas")
  
    let tarea = await coleccionTareas.findOne( { _id : idTarea })

    //Con la condicion del updateOne esta query sería innecesaria:
    if( tarea.usuario.idUsuario != context.user.id){
      reject("Solo puede modificar el estado de sus tareas, HDLGP")
      return
    }
  
    let rs = await coleccionTareas
      .updateOne( { "_id" : idTarea, "usuario.idUsuario" : context.user.id }, { $set : { estado : nuevoEstado }})
    resolve("OK")
  })
  
  //return "Llamada realizada en nombre de:"+context.user.custom_data.nombre ;
};

